---
name: "exam-drill-builder"
description: "Build or extend a single-file HTML exam drill for a course from its slide decks, lecture transcripts and the professor's own questions: set up a course, add a lecture, prepare an exam build, or review the bank."
---

# Exam drill builder

A drill is one self-contained HTML file (questions, figures, scheduler, exam
simulation, weak-spot analytics, reference tables, tell-apart tables and
objective guides) built from plain source files and published on GitHub Pages.
The reference implementation is the PHAR 4342 drill
(`github.com/lglouis3-create/Medicinal-chemistry`, `PHAR4342_Final_Drill.html`
and `src/`). Reuse its engine; write new content per course.

Four modes. Ask which one applies if the request does not say.

1. **New course**: copy the engine, write the course manifest, start the
   professor corpus, publish an empty-bank build.
2. **Add a lecture** (the usual session, 30–60 min): ingest one deck plus its
   transcript, write 15–30 questions in the professor's style, add tell-apart
   rows and reference tables, run the checks, rebuild, deliver.
3. **Exam build**: set the blueprint for the coming exam, add the professor's
   review material to the corpus, run the review agents, write the objective
   guides, rebuild, deliver with upload instructions.
4. **Bank review**: adversarial fact and style review of existing questions.

## Where things live

- The course's Claude Project holds the decks (PDF), the transcripts (one doc
  per lecture, labelled by date), the professor's polls, practice exams, prep
  sheets and review lists, and `claude/drill-app-state.md`, the running state
  doc for that course's drill (bank counts, verified slide facts, conflicts,
  build order, delivery status). Read it first in every session; update it at
  the end of every session.
- The GitHub repo holds `src/` (engine + content) and the built HTML at the
  root, served by GitHub Pages. One repo per course.
- The session workspace is scratch. Nothing is delivered until it is built,
  checked, committed and handed over.

## Engine files (course-agnostic; copy unchanged into a new course)

`shell.html` (CSS, storage shim, spaced-repetition scheduler, helpers),
`views.js` (topics, quiz, weak spots, exam sim, atlas, guides, tell apart,
reference, settings), `build.py` (concatenates the sources into the HTML and
syntax-checks each), `test.js`, `style_check.js`, `render_test.js`,
`explain_check.js`, `cite_check.py`, `coverage_check.py`, `browser_test.py`
(Playwright), `harvest.py` (+ `harvest_mask.py` for crops that print the
answer). Course-specific constants that the engine still carries and that a
new course must set: the page title, the storage namespace `NS`, the exam
blueprint (`BLUEPRINT`, `EXAM_SATA`, the exam minutes, the pool definitions
in `beginExam`, `weightedPool` and the Weak spots `pools`). Move them into one
`course.js` manifest the first time a second course is set up.

## Content files (per course)

- `q*.js`: question arrays, one file per lecture or block. `q1_*.js` also holds
  `TOPICS` (topic → subtopics with slide ranges, professor per topic).
- `images.json`: slide crops as data URLs, keyed; made by the harvest scripts,
  never by hand. Crops that print the answer get a masked copy for the question
  and a `_labeled` copy for the concept block.
- `reference.js`, `tell.js`, `guide.js`: HTML in template strings (no backtick,
  no `${` inside); figures as `{{fig:key|caption}}` tokens.
- `STYLE.md` (professor corpus): every poll, practice, prep-sheet and review
  item verbatim, plus the formats observed. This file decides how questions are
  worded; grow it every lecture.

## Question schema

```
{id:'cyp-e4', prof:'Sikazwe', tier:'new', exam:'final', topic:'cyp', sub:'expr',
 concept:'pie-expression-vs-drugs', tags:['recall'], source:'slide'|'transcript'|'both',
 multi:false, lowYield:false, dupOf:'other-id',
 stem:'…', img:'crop_key', fg:'atlas_key',
 options:[{t:'…', correct:true, why:'…'}, …],
 teach:'…', teachImg:'crop_key', note:'…', quote:'…',
 cite:'Lecture #13 (MCMet-9_15_2026.pdf) slide 14'}
```

Rules that every question obeys (the checks enforce most of them):
- One correct option, or `multi:true` with two or more correct and at least one
  distractor; a select-all stem ends "Select all that apply."
- Stems ask the chemistry, never "what does the slide say"; one sentence; no
  reference to the lecture, the deck or the course in the stem.
- Options 1–6 words where the fact allows, parallel in form, the correct one
  not the longest; reasoning goes in `why`, never in the option text.
- Every option has a `why` that says why it is right or what error picking it
  reveals. `teach` explains the concept behind the item.
- `cite` names the deck file and the slide number. `source:'transcript'` or
  `'both'` whenever a fact came from the audio; the app renders the flag.
- Every number, name and claim is on the cited slide or in the transcript. If
  it cannot be pointed at, it is not written; no placeholder values, no
  textbook knowledge presented as slide content.
- When two sources disagree, the question carries a `note` stating both and
  which one an exam written from the lectures keys.
- Expand each abbreviation once. No metaphors, no study advice, no sentence
  about the drill itself.
- `concept` groups wordings of one idea; the scheduler retests a missed concept
  with a different question. `dupOf` stops two versions of one fact sharing an
  exam paper; `lowYield` keeps a slide aside out of the paper.

## Mode 2: add a lecture

1. Read `claude/drill-app-state.md`. Confirm the deck and transcript are in the
   Project (check before asking for uploads).
2. Dump the slide text (`pdfplumber`, page N = slide N) to a scratch file;
   render picture slides (`pdftoppm`) and read them. Handwriting over slides is
   the student's, not the lecturer's.
3. Read the transcript once. Pull: exam-emphasis cues, exact terms, worked
   examples, corrections of the slides, anything he says will be on the exam.
   Append every poll or practice item he used to `STYLE.md` verbatim.
4. Crop the figures the questions will need (`harvest.py` spec entry per crop;
   masked copies where the crop prints the answer).
5. Write the questions: 15–30 per lecture, one per testable point, in the
   professor's formats from `STYLE.md` (his "which statement is WRONG", "Select
   TWO", "All … EXCEPT", TRUE/FALSE, named-patient case, reaction-scheme
   "What enzymes are implicated…"). Add confusable pairs to `tell.js` (looks
   alike / what separates them / the trap / slide) and any table the questions
   keep returning to, to `reference.js`.
6. Build and run every check; fix until all pass:
   `python3 build.py && node test.js && node style_check.js && node
   render_test.js && python3 cite_check.py && python3 coverage_check.py &&
   python3 browser_test.py`.
7. Commit to the local clone, grep the tree and any zip for tokens, deliver
   the HTML (and a zip of changed `src/` files) with SendUserFile, and update
   `claude/drill-app-state.md` (counts, new slide facts, conflicts).

## Mode 3: exam build

1. Blueprint from the professor's announcement: question count, minutes, share
   per professor and per lecture block, select-all count if stated. Set it in
   the manifest; the exam draw follows it, with `dupOf` and `lowYield` honoured.
2. Add the review list, practice exam and prep sheet to `STYLE.md`; run
   `coverage_check.py` against the stated scope and fill the holes.
3. Review round with agents, in parallel, slices of ~100 questions each: a
   brief that names the sources, the rules above and the report format; each
   returns JSON findings (id, issue type, note, proposed stem and options with
   the same correctness pattern). Apply accepted rewrites by script, never by
   hand-retyping; keyed answers change only with a stated source.
4. Objective guides (`guide.js`): one section per objective on the professor's
   objectives slide, layout fixed: the words on the slides → the points in
   slide order with (T) transcript quotes → memory hook → his poll on that
   objective with each option judged → how he asks it and how to answer.
   Writers work only from the slide dump and the transcript; separate verifier
   agents then check every sentence against rendered slides and the transcript
   (severity: wrong answer > wrong fact > unsupported > citation > style) and
   the fixes are applied before the build.
5. Build, all checks, commit, deliver, doc update. Tell the user in one line
   how to publish: upload the same-named HTML over the old one at the repo root;
   Pages redeploys in a few minutes; progress in localStorage survives because
   question ids do not change.

## Mode 4: bank review

Adversarial only: for each question, is the keyed option right per the source;
is any distractor also defensible; is every claim in every `why` and `teach`
sourced; does the cite point at the slide that carries it; does the stem give
the answer away; is there a duplicate. Report format per finding: id,
severity, exact quote, source quote, fix. Skip clean questions.

## Publishing and security

- Push from a cloud session may be refused by the git proxy; then deliver the
  built HTML plus a zip of changed `src/` files and give the upload steps.
  From Claude Code or a linked computer, push directly.
- A token lives only in `.git/config`, never in tracked files, bundles or
  zips; grep before packaging every time.
- The site is shared with classmates: personal mnemonics or names stay out of
  the shared build unless the user asks for them there.

## Delivery standard

One short paragraph on what changed and what was checked; the file card; the
upload line. Never claim a check passed that did not run. If a fact could not
be sourced, say so and leave it out rather than fill it in.